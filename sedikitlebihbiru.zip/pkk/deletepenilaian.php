<?php 
 
 include 'koneksi.php';

$No_urut = $_GET['No_Urut'];
$result = mysqli_query($conn, "DELETE FROM matriks_penilaian_kinerja_lam_infokom WHERE No_urut=$No_urut");
header("Location: penilaian.php");
?>